package com.app.theatreseating.application;
import com.app.theatreseating.theatre.*;
import com.app.theatreseating.ticketrequest.*;
import com.app.theatreseating.assignment.*;


public class Application {

	public static void main(String[] args) {
		
		/////Designing Theatre's layout/////
		
		Theatre t=new Theatre();
		
	    ////Row, Section and seats
		//////////Theatre's layout//////////
		///    	S1 S2 S3 S4              ///
		/// R1 	6  6                     /// 
		/// R2 	3  5  5  3	             /// 
		/// R3 	4  6  6  4               ///
		/// R4 	2  8  8  2               ///
		///	R5 	6  6                     /// 
		////////////////////////////////////
		
		t.getLayout().add(new Theatre(1,1,6));  //Row 1 ; Section 1
		t.getLayout().add(new Theatre(1,2,6));  //Row 1 ; Section 2
		
		t.getLayout().add(new Theatre(2,1,3));  //Row 2 ; Section 1
		t.getLayout().add(new Theatre(2,2,5));  //Row 2 ; Section 2
		t.getLayout().add(new Theatre(2,3,5));  //Row 2 ; Section 3
		t.getLayout().add(new Theatre(2,4,3));  //Row 2 ; Section 4
		
		t.getLayout().add(new Theatre(3,1,4));  //Row 3 ; Section 1
		t.getLayout().add(new Theatre(3,2,6));  //Row 3 ; Section 2
		t.getLayout().add(new Theatre(3,3,6));  //Row 3 ; Section 3
		t.getLayout().add(new Theatre(3,4,4));  //Row 3 ; Section 4
		
		t.getLayout().add(new Theatre(4,1,2));  //Row 4 ; Section 1
		t.getLayout().add(new Theatre(4,2,8));  //Row 4 ; Section 2
		t.getLayout().add(new Theatre(4,3,8));  //Row 4 ; Section 3
		t.getLayout().add(new Theatre(4,4,2));  //Row 4 ; Section 4
		
		t.getLayout().add(new Theatre(5,1,6));  //Row 5 ; Section 1
		t.getLayout().add(new Theatre(5,2,6));  //Row 5 ; Section 2
		
		
		//// Show Theatre's layout ////////
		
		t.showLayout();
		
		System.out.println("\n");
		
		//// Request Tickets //////////////
		
		TicketRequest tr= new TicketRequest();
		
	    ////Name, tickets number
		
		///////////////////////////////////
		///  	Smith 2                 ///  
		///  	Jones 5                 ///   
		///  	Davis 6                 ///
		///  	Wilson 100              /// 
		///  	Johnson 3               ///
		///  	Williams 4              /// 
		///  	Brown 8                 ///
		///  	Miller 12               ///  
        ///////////////////////////////////
 
		tr.getRequest().add(new TicketRequest("Smith",2));  //Adding Smith ; request 2 
		tr.getRequest().add(new TicketRequest("Jones",5));  //Adding Jones ; request 5
		tr.getRequest().add(new TicketRequest("Davis",6));  //Adding Davis ; request 6
		tr.getRequest().add(new TicketRequest("Wilson",100));  //Adding Wilson ; request 100
		tr.getRequest().add(new TicketRequest("Johnson",3));  //Adding Jhonson ; request 3
		tr.getRequest().add(new TicketRequest("Williams",4));  //Adding Williams ; request 4
		tr.getRequest().add(new TicketRequest("Brown",8));  //Adding Brown ; request 8
		tr.getRequest().add(new TicketRequest("Miller",12));  //Adding Miller ; request 12
		
	    /// Show Theatre's layout /////////
		
		tr.showRequest();
			
		System.out.println("");
		
		/// Assignment and confirmation /// 
		
		Assignment a=new Assignment(t,tr);
		
		/// Show Confirmation /////////////
		
		a.showConfirmation();
		
		///////////////////////////////////
	}

}
