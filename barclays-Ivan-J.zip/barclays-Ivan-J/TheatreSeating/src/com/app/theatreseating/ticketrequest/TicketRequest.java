package com.app.theatreseating.ticketrequest;
import java.util.List;

import java.util.ArrayList;

public class TicketRequest {

	private String name;
	private int tickets;
	private List<TicketRequest> request; 

	public TicketRequest() {
		super();
		this.name = null;
		this.tickets = 0;
		request = new ArrayList <TicketRequest>();
	}
	
	public TicketRequest(String name,int tickets) {
		super();
		this.name = name;
		this.tickets = tickets;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getTickets() {
		return tickets;
	}

	public void setTickets(int tickets) {
		this.tickets = tickets;
	}

	public List<TicketRequest> getRequest() {
		return request;
	}

	public void setRequest(List<TicketRequest> request) {
		this.request = request;
	}
	
	public void showRequest(){	
		//System.out.println("Request:");
		try {
			for( TicketRequest item: request) {
				System.out.println(item.getName()+" "+item.getTickets());
			}
		}catch(Exception e) {
			System.out.println(e.getCause());
		}
	}


}
