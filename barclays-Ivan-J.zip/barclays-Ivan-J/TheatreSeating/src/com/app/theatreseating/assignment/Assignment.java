package com.app.theatreseating.assignment;
import com.app.theatreseating.theatre.*;
import com.app.theatreseating.ticketrequest.*;

public class Assignment {
	
	private Theatre theatre;
	private TicketRequest ticketrequest;
	private int controw;
	
	public Assignment(Theatre theatre, TicketRequest ticketrequest) {
		super();
		this.theatre = theatre;
		this.ticketrequest = ticketrequest;
		this.controw = 0;
	}

	public Theatre getTheatre() {
		return theatre;
	}

	public void setTheatre(Theatre theatre) {
		this.theatre = theatre;
	}

	public TicketRequest getTicketrequest() {
		return ticketrequest;
	}

	public void setTicketrequest(TicketRequest ticketrequest) {
		this.ticketrequest = ticketrequest;
	}
		
	private int totalTickets() {
		int size=0;
		try {
			for(Theatre item : this.getTheatre().getLayout()) { 
				size = size+item.getSeat();
			}
			return size;
		}catch(Exception e) {
			System.out.println(e.getCause());
			return -1;
		}
	}
	
	private String answerConfirmation(int tickets) {
		int count = 0;
		boolean assignment = false;
		if(tickets > totalTickets()) {
			return "Sorry, we can't handle your party.";
		}else {
			for(Theatre item : this.getTheatre().getLayout()) {
				if(tickets > item.getSeat()) {
					count ++;
					if(count == this.getTheatre().getLayout().size()) {
						return "Call to split party.";
					}	
				}else{
					if(controw != item.getRow() && assignment == false && (item.getSeat() - tickets)>=0){
						assignment = true;
						controw=item.getRow();
						item.setSeat(item.getSeat()-tickets);
						return "Row "+item.getRow() + " Section " + item.getSection();
					}	
				}
			}
		}
		return null;
	}
	
	public void showConfirmation() {
		//System.out.println("Confirmation:");
		try {
			for(TicketRequest item : this.getTicketrequest().getRequest()) {
				System.out.println(item.getName() + " " + this.answerConfirmation(item.getTickets()));
			}
		}catch(Exception e) {
			System.out.println(e.getCause());
		}
	}

}
