package com.app.theatreseating.theatre;
import java.util.List;
import java.util.ArrayList;

public class Theatre {

	private int row;
	private int section;
	private int seat;
	private List<Theatre> layout;

	public Theatre() {
		super();
		this.row = 0;
		this.section = 0;
		this.seat = 0;
		layout = new ArrayList<Theatre>(); 
	}
	
	public Theatre(int row,int section,int seat) {
		super();
		this.row = row;
		this.section = section;
		this.seat = seat;
	}
	
	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}
	
	public int getSection() {
		return section;
	}

	public void setSection(int section) {
		this.section = section;
	}

	public int getSeat() {
		return seat;
	}

	public void setSeat(int seat) {
		this.seat = seat;
	}
	
	public List<Theatre> getLayout() {
		return layout;
	}

	public void setTheatre(List<Theatre> layout) {
		this.layout = layout;
	}
	
	public void showLayout(){	
		//System.out.println("Layout Theatre:");
		int showrows = 1;
		try {
			for(Theatre item: layout) {
				if(showrows == item.getRow()){
					System.out.print(item.getSeat()+" ");
				}else {
					System.out.print("\n");
					System.out.print(item.getSeat()+" ");
				}
				showrows = item.getRow();
			}
		}catch(Exception e) {
			System.out.println(e.getCause());
		}
	}
	
}
