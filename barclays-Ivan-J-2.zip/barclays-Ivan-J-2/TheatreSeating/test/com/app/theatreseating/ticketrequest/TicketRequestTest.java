package com.app.theatreseating.ticketrequest;

import static org.junit.Assert.*;

import org.junit.Test;

import com.app.theatreseating.theatre.Theatre;

import junit.framework.Assert;

public class TicketRequestTest {

	@Test
	public void test() {
		
		TicketRequest tr=TicketRequest.getInstance();  
		
		//when "Ivan->request 2 tickets  "	
		
		tr.getRequest().add(new TicketRequest("Ivan",2));
		
		// List <TicketRequest> is populated: 	
		    Assert.assertEquals(tr.getRequest().size(),1);
			
			Assert.assertEquals(tr.getRequest().get(0).getName(),"Ivan");
			Assert.assertEquals(tr.getRequest().get(0).getTickets(),2);
			
		//////////////////////////////	
			
		//when "Jose->request 15 tickets  "	
			
		tr.getRequest().add(new TicketRequest("Jose",15));
			
		// List <TicketRequest> is populated: 	
	    Assert.assertEquals(tr.getRequest().size(),2);
				
		Assert.assertEquals(tr.getRequest().get(1).getName(),"Jose");
		Assert.assertEquals(tr.getRequest().get(1).getTickets(),15);
				
		//////////////////////////////	
		
		//when "Alex->request 1 tickets  "	
		
		tr.getRequest().add(new TicketRequest("Alex",1));
		
		// List <TicketRequest> is populated: 	
		Assert.assertEquals(tr.getRequest().size(),3);
			
		Assert.assertEquals(tr.getRequest().get(2).getName(),"Alex");
		Assert.assertEquals(tr.getRequest().get(2).getTickets(),1);
			
		//////////////////////////////	
				
	
	    //when "Carlos->request 60 tickets  "	
		
		tr.getRequest().add(new TicketRequest("Carlos",60));
		
		// List <TicketRequest> is populated: 	
		Assert.assertEquals(tr.getRequest().size(),4);
			
		Assert.assertEquals(tr.getRequest().get(3).getName(),"Carlos");
		Assert.assertEquals(tr.getRequest().get(3).getTickets(),60);
			
		//////////////////////////////	
	
		
		tr.showRequest();				
				
	}

}
