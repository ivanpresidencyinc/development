package com.app.theatreseating.assignment;

import org.junit.Test;

import com.app.theatreseating.theatre.Theatre;
import com.app.theatreseating.ticketrequest.TicketRequest;

import junit.framework.Assert;

public class AssignmentTest {

	@Test
	public void test() {
		
	    Theatre t=Theatre.getInstance();  
		
		//when 1,1,3	
			t.getLayout().add(new Theatre(1,1,3));
		
		// List <Theatre> is populated: 	
			Assert.assertEquals(t.getLayout().size(),1);
			
			Assert.assertEquals(t.getLayout().get(0).getRow(),1);
			Assert.assertEquals(t.getLayout().get(0).getSection(),1);
			Assert.assertEquals(t.getLayout().get(0).getSeat(),3);
			
		//////////////////////////////	
			
		
		//when 1,2,3
			t.getLayout().add(new Theatre(1,2,3));
				
		// List <Theatre> is populated: 	
			Assert.assertEquals(t.getLayout().size(),2);
			
			Assert.assertEquals(t.getLayout().get(1).getRow(),1);
			Assert.assertEquals(t.getLayout().get(1).getSection(),2);
			Assert.assertEquals(t.getLayout().get(1).getSeat(),3);
		
		//////////////////////////////	
			
		//when 2,1,12
			t.getLayout().add(new Theatre(2,1,12));
						
		// List <Theatre> is populated:
			
			Assert.assertEquals(t.getLayout().size(),3);
			
			Assert.assertEquals(t.getLayout().get(2).getRow(),2);
			Assert.assertEquals(t.getLayout().get(2).getSection(),1);
			Assert.assertEquals(t.getLayout().get(2).getSeat(),12);
				
		//////////////////////////////
			
		//when 2,2,12
			t.getLayout().add(new Theatre(2,2,12));
								
		// List <Theatre> is populated: 	
			Assert.assertEquals(t.getLayout().size(),4);
			
			Assert.assertEquals(t.getLayout().get(3).getRow(),2);
			Assert.assertEquals(t.getLayout().get(3).getSection(),2);
			Assert.assertEquals(t.getLayout().get(3).getSeat(),12);
			
		//////////////////////////////	
			
			TicketRequest tr=TicketRequest.getInstance();  
			
			//when "Ivan->request 2 tickets  "	
			
			tr.getRequest().add(new TicketRequest("Ivan",2));
			
			// List <TicketRequest> is populated: 	
			    Assert.assertEquals(tr.getRequest().size(),1);
				
				Assert.assertEquals(tr.getRequest().get(0).getName(),"Ivan");
				Assert.assertEquals(tr.getRequest().get(0).getTickets(),2);
				
			//////////////////////////////	
				
			//when "Jose->request 15 tickets  "	
				
			tr.getRequest().add(new TicketRequest("Jose",15));
				
			// List <TicketRequest> is populated: 	
		    Assert.assertEquals(tr.getRequest().size(),2);
					
			Assert.assertEquals(tr.getRequest().get(1).getName(),"Jose");
			Assert.assertEquals(tr.getRequest().get(1).getTickets(),15);
					
			//////////////////////////////	
			
			//when "Alex->request 1 tickets  "	
			
			tr.getRequest().add(new TicketRequest("Alex",1));
			
			// List <TicketRequest> is populated: 	
			Assert.assertEquals(tr.getRequest().size(),3);
				
			Assert.assertEquals(tr.getRequest().get(2).getName(),"Alex");
			Assert.assertEquals(tr.getRequest().get(2).getTickets(),1);
				
			//////////////////////////////	
					
		
		    //when "Carlos->request 60 tickets  "	
			
			tr.getRequest().add(new TicketRequest("Carlos",60));
			
			// List <TicketRequest> is populated: 	
			Assert.assertEquals(tr.getRequest().size(),4);
				
			Assert.assertEquals(tr.getRequest().get(3).getName(),"Carlos");
			Assert.assertEquals(tr.getRequest().get(3).getTickets(),60);
				
			//////////////////////////////	

			
			
		Assignment a=Assignment.getInstance();
		a=new Assignment(t,tr);
		
		a.showConfirmation();
	}

}
