package com.app.theatreseating.theatre;

import static org.junit.Assert.*;
import org.junit.Test;
import junit.framework.Assert;

public class TheatreTest {

	@Test
	public void test() {
		
	    Theatre t=Theatre.getInstance();  
	
	//when 1,1,3	
		t.getLayout().add(new Theatre(1,1,3));
	
	// List <Theatre> is populated: 	
		Assert.assertEquals(t.getLayout().size(),1);
		
		Assert.assertEquals(t.getLayout().get(0).getRow(),1);
		Assert.assertEquals(t.getLayout().get(0).getSection(),1);
		Assert.assertEquals(t.getLayout().get(0).getSeat(),3);
		
	//////////////////////////////	
		
	
	//when 1,2,3
		t.getLayout().add(new Theatre(1,2,3));
			
	// List <Theatre> is populated: 	
		Assert.assertEquals(t.getLayout().size(),2);
		
		Assert.assertEquals(t.getLayout().get(1).getRow(),1);
		Assert.assertEquals(t.getLayout().get(1).getSection(),2);
		Assert.assertEquals(t.getLayout().get(1).getSeat(),3);
	
	//////////////////////////////	
		
	//when 2,1,12
		t.getLayout().add(new Theatre(2,1,12));
					
	// List <Theatre> is populated:
		
		Assert.assertEquals(t.getLayout().size(),3);
		
		Assert.assertEquals(t.getLayout().get(2).getRow(),2);
		Assert.assertEquals(t.getLayout().get(2).getSection(),1);
		Assert.assertEquals(t.getLayout().get(2).getSeat(),12);
			
	//////////////////////////////
		
	//when 2,2,12
		t.getLayout().add(new Theatre(2,2,12));
							
	// List <Theatre> is populated: 	
		Assert.assertEquals(t.getLayout().size(),4);
		
		Assert.assertEquals(t.getLayout().get(3).getRow(),2);
		Assert.assertEquals(t.getLayout().get(3).getSection(),2);
		Assert.assertEquals(t.getLayout().get(3).getSeat(),12);
		
	//////////////////////////////	
		
		t.showLayout();
		
	}

}
