package com.app.theatreseating.application;

import org.junit.Test;

public class InputApplicationTest {

	@Test
	public void test() {
		
		InputApplication ia=InputApplication.getInstance();

	}

}
