package com.app.theatreseating.application;


import org.junit.Test;

import junit.framework.Assert;

public class ApplicationTest {

	@Test
	public void test() {
		InputApplication ip=InputApplication.getInstance();	
		ip.inputProduction();
	}

}
