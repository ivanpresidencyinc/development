/* InputApplication: Design the Theatre's layout, the requested and 
 * shows the final assignment confirmation 
 */

//Example:

////Row, Section and seats
		//////////Theatre's layout//////////
		///    	S1 S2 S3 S4              ///
		/// R1 	6  6                     /// 
		/// R2 	3  5  5  3	             /// 
		/// R3 	4  6  6  4               ///
		/// R4 	2  8  8  2               ///
		///	R5 	6  6                     /// 
		////////////////////////////////////

////Name, tickets number
		
		///////////////////////////////////
		///  	Smith 2                 ///  
		///  	Jones 5                 ///   
		///  	Davis 6                 ///
		///  	Wilson 100              /// 
		///  	Johnson 3               ///
		///  	Williams 4              /// 
		///  	Brown 8                 ///
		///  	Miller 12               ///  
        ///////////////////////////////////
 

package com.app.theatreseating.application;
import com.app.theatreseating.theatre.*;
import com.app.theatreseating.ticketrequest.*;
import com.app.theatreseating.assignment.*;

import java.util.InputMismatchException;
import java.util.Scanner;


public class InputApplication {

	
	private Theatre theatre;
	private TicketRequest ticketrequest;
	private Assignment assignment;
	private static InputApplication inputapplication = null;

	
	public InputApplication() {
		super();
		theatre=Theatre.getInstance();
		ticketrequest=TicketRequest.getInstance();
		assignment=Assignment.getInstance();
	}

	public static InputApplication getInstance()
	{
	        if (inputapplication == null)
	        	inputapplication = new InputApplication();
	 
	        return inputapplication;
	}
	
	public Theatre getTheatre() {
		return theatre;
	}

	public void setTheatre(Theatre theatre) {
		this.theatre = theatre;
	}

	public TicketRequest getTicketrequest() {
		return ticketrequest;
	}

	public void setTicketrequest(TicketRequest ticketrequest) {
		this.ticketrequest = ticketrequest;
	}

	public Assignment getAssignment() {
		return assignment;
	}

	public void setAssignment(Assignment assignment) {
		this.assignment = assignment;
	}
	
		
	public void inputLayout(int row,int section, int seat) { 	
		this.getTheatre().getLayout().add(new Theatre(row,section,seat));		
	}
	
	public void showLayout() {
       
		this.getTheatre().showLayout();
		System.out.println("\n");
		
	}
		
	public void inputRequest(String name,int seats) {	
	    this.getTicketrequest().getRequest().add(new TicketRequest(name,seats)); 
	}
	
	
	public void showRequest() {
	     
		this.getTicketrequest().showRequest();
		System.out.println("\n");
	
	}
	
	
	public void showAsignamentet() {
	     
		this.setAssignment(new Assignment(this.getTheatre(),this.getTicketrequest()));		
		this.getAssignment().showConfirmation();
	
	}
	
	public void inputProduction(){
		
		
		Scanner reader = new Scanner(System.in);  
		
		String val="Y";
		int row=0;
		int section=0;
		int seat=0;
		
		System.out.println("Theatre Seating");
		System.out.print("");
		System.out.println("Layout:");
		
		while(val.equalsIgnoreCase("y")) {
		//Layout
			
			try {
				System.out.println("Input Row:");
				row = reader.nextInt();
				 
				System.out.println("Input Section:");
				section= reader.nextInt();
				 
				System.out.println("Input Seat numbers:");
				seat = reader.nextInt();
		
				this.inputLayout(row, section, seat);
				System.out.println("Add more elements? Y/N");
				val = reader.next();
			} catch (InputMismatchException e) {
                System.out.println("Please insert a correct value");
                reader.next();
            }
			
		}
		
		//Show Layout
		System.out.println("");
		System.out.println("Show Layout:");
		this.showLayout();
	
		val="y";
		
		//Generate Request
	
		System.out.println("");
		System.out.println("Request:");
	
		while(val.equalsIgnoreCase("y")) {
			try {
				System.out.println("Name: ");
				String name = reader.next();
		
				System.out.println("Number of tickets:");
				int seats = reader.nextInt();
		
				this.inputRequest(name, seats);
		
				System.out.println("Add more request? Y/N");
				val = reader.next();
			
			} catch (InputMismatchException e) {
            System.out.println("Please insert a correct value");
            reader.next();
			}
		}
		
		//Show Request
		reader.close();
		
		System.out.println("");
		System.out.println("Show Request:");
		this.showRequest();
		
		//Show Assignment:
		
		System.out.println("Show Assignment:");
		
		//Final assignment
		this.showAsignamentet();

		
	}
	
}