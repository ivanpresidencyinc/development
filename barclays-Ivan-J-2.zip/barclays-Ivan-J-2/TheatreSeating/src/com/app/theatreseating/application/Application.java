/*
 * Main application
 */

package com.app.theatreseating.application;

public class Application {

	
		public static void main(String[] args) {
			InputApplication ia = InputApplication.getInstance();
			ia.inputProduction();
		}

}
